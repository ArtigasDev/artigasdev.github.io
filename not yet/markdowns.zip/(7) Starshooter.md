---
name: Starshooter, Spatial Shoot
tools: [C#, Unity3D, Mobile]
image: 
description: Lorem ipsum.
---

{% include elements/video.html id="yx-faLIs8L0" %}

### Developed by:
- Ángel Artigas Pérez
- Miguel Astorga Badía
- Jordi Sans Solé

<p class="text-center">
{% include elements/button.html link="https://artigasdev.github.io/projects/" text="Back" %}
</p>