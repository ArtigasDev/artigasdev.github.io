---
name: Sinewave
tools: [C, SDL, assembler]
image: 
description: 
---





### Developed by: 
- Ángel Artigas Pérez 
- Jordi Sans Solé

<p class="text-center">
{% include elements/button.html link="https://artigasdev.github.io/projects/" text="Back" %}
</p>