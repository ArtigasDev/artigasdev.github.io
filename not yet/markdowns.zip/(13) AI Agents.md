---
name: AI Agents
tools: [AI, C++, SDL2]
image: 
description: Lorem ipsum.
---

{% include elements/video.html id="SLZAzNJeupM" %}


### Developed by: 
- Ángel Artigas Pérez 
- Jordi Sans Solé
- Miguel Astorga Badía

<p class="text-center">
{% include elements/button.html link="https://artigasdev.github.io/projects/" text="Back" %}
</p>